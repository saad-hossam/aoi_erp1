{{-- resources/views/dashboard/partials/section-menu-left.blade.php --}}

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
    /* ============================================================ */
    /*                    Sidebar — Perm Style                       */
    /* ============================================================ */
    .section-menu-left {
        --s-primary: #6366f1;
        --s-primary-soft: #eef2ff;
        --s-primary-glow: rgba(99, 102, 241, .35);
        --s-text: #1f2937;
        --s-muted: #6b7280;
        --s-border: #e5e7eb;
        --s-bg: #ffffff;
        --s-bg-soft: #f9fafb;
        --s-hover: #f3f4f6;
        --s-danger: #ef4444;

        width: 340px;              /* ← زيادة العرض من 280px إلى 340px */
        min-width: 340px;
        height: 100vh;
        background: var(--s-bg);
        border-left: 1px solid var(--s-border);
        display: flex;
        flex-direction: column;
        overflow: hidden;
        font-family: inherit;
        position: relative;
        z-index: 1000;
    }

    /* ======================= الشعار ======================= */
    .section-menu-left .box-logo {
        padding: 26px 24px;
        border-bottom: 1px solid var(--s-border);
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        background: linear-gradient(180deg, #ffffff, #fafbff);
    }
    .section-menu-left .box-logo a {
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        transition: transform .25s ease;
    }
    .section-menu-left .box-logo a:hover {
        transform: scale(1.05);
    }
    .section-menu-left .box-logo img#logo_header {
        width: 88px !important;    /* ← زيادة حجم الشعار من 72px إلى 88px */
        height: 88px !important;
        border-radius: 50%;
        display: block;
        border: 3px solid #fff;
        box-shadow:
            0 8px 20px rgba(99, 102, 241, .25),
            0 0 0 3px rgba(99, 102, 241, .12);
        object-fit: cover;
    }
    .section-menu-left .button-show-hide {
        position: absolute;
        top: 50%;
        left: 18px;
        transform: translateY(-50%);
        width: 38px;
        height: 38px;
        border-radius: 10px;
        background: var(--s-primary-soft);
        color: var(--s-primary);
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        font-size: 16px;
        transition: all .2s ease;
    }
    .section-menu-left .button-show-hide:hover {
        background: var(--s-primary);
        color: #fff;
        transform: translateY(-50%) scale(1.08);
    }

    /* ======================= منطقة القائمة ======================= */
    .section-menu-left .center {
        flex: 1;
        overflow-y: auto;
        overflow-x: hidden;
        padding: 20px 16px 28px;
        scrollbar-width: thin;
        scrollbar-color: #cbd5e1 transparent;
    }
    .section-menu-left .center::-webkit-scrollbar {
        width: 8px;
    }
    .section-menu-left .center::-webkit-scrollbar-track {
        background: transparent;
    }
    .section-menu-left .center::-webkit-scrollbar-thumb {
        background: #cbd5e1;
        border-radius: 4px;
    }
    .section-menu-left .center::-webkit-scrollbar-thumb:hover {
        background: var(--s-primary);
    }

    /* ======================= كل قسم ======================= */
    .section-menu-left .center-item {
        margin-bottom: 22px;
    }
    .section-menu-left .center-item:last-child {
        margin-bottom: 0;
    }

    /* ======================= عنوان القسم ======================= */
    .section-menu-left .center-heading {
        font-size: 13.5px;         /* ← زيادة من 11.5px */
        font-weight: 800;          /* ← أثقل */
        color: var(--s-muted);
        text-transform: uppercase;
        letter-spacing: 1.4px;
        padding: 10px 16px;
        margin-bottom: 8px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .section-menu-left .center-heading::before {
        content: '';
        width: 4px;
        height: 18px;
        background: linear-gradient(180deg, #6366f1, #8b5cf6);
        border-radius: 2px;
        flex-shrink: 0;
    }

    /* ======================= قائمة الروابط ======================= */
    .section-menu-left .menu-list {
        list-style: none;
        margin: 0;
        padding: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
    }

    .section-menu-left .menu-item {
        position: relative;
    }

    .section-menu-left .menu-item > a {
        display: flex;
        align-items: center;
        gap: 14px;                 /* ← زيادة من 12px */
        padding: 14px 18px;        /* ← زيادة من 11px 14px */
        border-radius: 12px;
        color: var(--s-text);
        text-decoration: none;
        font-size: 17px;           /* ← زيادة كبيرة: من 14.5px إلى 17px */
        font-weight: 600;          /* ← أثقل: من 500 إلى 600 */
        transition: all .2s ease;
        position: relative;
        overflow: hidden;
    }

    /* تأثير الخلفية عند hover */
    .section-menu-left .menu-item > a::before {
        content: '';
        position: absolute;
        inset: 0;
        background: linear-gradient(90deg, transparent, rgba(99, 102, 241, .06));
        opacity: 0;
        transition: opacity .2s ease;
        pointer-events: none;
    }

    .section-menu-left .menu-item > a:hover {
        background: var(--s-hover);
        color: var(--s-primary);
        transform: translateX(-3px);
    }
    .section-menu-left .menu-item > a:hover::before {
        opacity: 1;
    }
    .section-menu-left .menu-item > a:hover .icon {
        background: var(--s-primary-soft);
        color: var(--s-primary);
        transform: scale(1.08);
    }

    /* ======================= الأيقونة ======================= */
    .section-menu-left .menu-item > a .icon {
        width: 42px;               /* ← زيادة من 34px */
        height: 42px;
        border-radius: 11px;
        background: var(--s-bg-soft);
        color: var(--s-muted);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 17px;           /* ← زيادة من 14px */
        flex-shrink: 0;
        transition: all .25s ease;
        border: 1px solid transparent;
    }

    /* ======================= النص ======================= */
    .section-menu-left .menu-item > a .text {
        flex: 1;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        transition: color .2s ease;
        line-height: 1.4;
    }

    /* ======================= العنصر النشط ======================= */
    .section-menu-left .menu-item > a.active {
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff !important;
        font-weight: 700;          /* ← أثقل للنشط */
        box-shadow:
            0 6px 16px rgba(99, 102, 241, .35),
            0 0 0 1px rgba(99, 102, 241, .15);
        transform: translateX(0);
    }
    .section-menu-left .menu-item > a.active::after {
        content: '';
        position: absolute;
        right: -12px;
        top: 50%;
        transform: translateY(-50%);
        width: 4px;
        height: 60%;
        background: #fff;
        border-radius: 4px 0 0 4px;
        opacity: .6;
    }
    .section-menu-left .menu-item > a.active .icon {
        background: rgba(255, 255, 255, .2);
        color: #fff;
        border-color: rgba(255, 255, 255, .25);
        transform: scale(1.05);
    }
    .section-menu-left .menu-item > a.active:hover {
        transform: translateY(-1px);
        box-shadow:
            0 10px 22px rgba(99, 102, 241, .45),
            0 0 0 1px rgba(99, 102, 241, .15);
    }
    .section-menu-left .menu-item > a.active:hover .icon {
        background: rgba(255, 255, 255, .3);
    }

    /* ======================= رسالة "لا توجد عناصر" ======================= */
    .section-menu-left .menu-item .text.text-muted {
        color: var(--s-muted) !important;
        font-size: 15px;           /* ← زيادة من 13px */
        font-style: italic;
        padding: 12px 16px;
        display: block;
    }

    /* ======================= حالة الجوال ======================= */
    @media (max-width: 991px) {
        .section-menu-left {
            position: fixed;
            top: 0;
            right: 0;
            height: 100vh;
            transform: translateX(100%);
            transition: transform .3s ease;
            box-shadow: -8px 0 32px rgba(0, 0, 0, .12);
        }
        .section-menu-left.open {
            transform: translateX(0);
        }
    }

    /* ======================= أنيميشن دخول العناصر ======================= */
    @keyframes sidebarItemIn {
        from { opacity: 0; transform: translateX(10px); }
        to   { opacity: 1; transform: translateX(0); }
    }
    .section-menu-left .menu-item {
        animation: sidebarItemIn .3s ease both;
    }
    .section-menu-left .menu-item:nth-child(1) { animation-delay: .02s; }
    .section-menu-left .menu-item:nth-child(2) { animation-delay: .04s; }
    .section-menu-left .menu-item:nth-child(3) { animation-delay: .06s; }
    .section-menu-left .menu-item:nth-child(4) { animation-delay: .08s; }
    .section-menu-left .menu-item:nth-child(5) { animation-delay: .10s; }
    .section-menu-left .menu-item:nth-child(6) { animation-delay: .12s; }
    .section-menu-left .menu-item:nth-child(7) { animation-delay: .14s; }
    .section-menu-left .menu-item:nth-child(8) { animation-delay: .16s; }
</style>

<div class="section-menu-left" id="sidebar">
    <div class="box-logo">
        <a href="{{ route('admin.index') }}" id="site-logo-inner">
            <img id="logo_header" alt="logo"
                 src="{{ asset('assets/front/assets') }}/images/logo_ar.png">
        </a>
        <div class="button-show-hide" id="sidebarClose" style="display: none;">
            <i class="fas fa-times"></i>
        </div>
    </div>

    <div class="center">
        {{-- ============ الرئيسية ============ --}}
        <div class="center-item">
            <ul class="menu-list">
                <li class="menu-item">
                    <a href="{{ route('admin.index') }}"
                       class="{{ request()->routeIs('admin.index') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-th-large"></i></div>
                        <div class="text">لوحة التحكم</div>
                    </a>
                </li>
            </ul>
        </div>

        {{-- ============ الإدارة ============ --}}
        <div class="center-item">
            <div class="center-heading">الإدارة</div>
            <ul class="menu-list">

                <li class="menu-item">
                    <a href="{{ route('emps.index') }}"
                       class="{{ request()->routeIs('emps.*') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-user"></i></div>
                        <div class="text">المستخدمون</div>
                    </a>
                </li>

                <li class="menu-item">
                    <a href="{{ route('permissions.index') }}"
                       class="{{ request()->routeIs('permissions.*') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-shield-alt"></i></div>
                        <div class="text">الصلاحيات</div>
                    </a>
                </li>

                <li class="menu-item">
                    <a href="{{ route('roles.index') }}"
                       class="{{ request()->routeIs('roles.*') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-user-tag"></i></div>
                        <div class="text">الأدوار</div>
                    </a>
                </li>

                <li class="menu-item">
                    <a href="{{ route('admin.pages.index') }}"
                       class="{{ request()->routeIs('admin.pages.*') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-file-alt"></i></div>
                        <div class="text">الصفحات</div>
                    </a>
                </li>

                <li class="menu-item">
                    <a href="{{ route('admin.tree-nodes.index') }}"
                       class="{{ request()->routeIs('admin.tree-nodes.*') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-sitemap"></i></div>
                        <div class="text">عقد الشجرة</div>
                    </a>
                </li>

                <li class="menu-item">
                    <a href="{{ route('admin.tree-page-mappings.index') }}"
                       class="{{ request()->routeIs('admin.tree-page-mappings.*') ? 'active' : '' }}">
                        <div class="icon"><i class="fas fa-link"></i></div>
                        <div class="text">ربط الشجرة بالصفحات</div>
                    </a>
                </li>

            </ul>
        </div>

        {{-- ============ نظام ERP الديناميكي (Navigation) ============ --}}
        @if(!empty($navigation))
            <div class="center-item">
                <div class="center-heading">{{ $navigation['root']->label }}</div>

                <ul class="menu-list">
                    @forelse($navigation['children'] as $item)
                        @can($item['node']->label)
                            @include('dashboard.partials.navigation-item', ['item' => $item])
                        @endcan
                    @empty
                        <li class="menu-item">
                            <div class="text text-muted">لا توجد عناصر</div>
                        </li>
                    @endforelse
                </ul>
            </div>
        @endif

    </div>
</div>