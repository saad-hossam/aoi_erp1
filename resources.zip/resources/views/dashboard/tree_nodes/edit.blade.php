@extends('layouts.dashboard.app')
@section('content')

{{-- Font Awesome --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
    .perm-page {
        --p-primary: #6366f1;
        --p-primary-soft: #eef2ff;
        --p-danger: #ef4444;
        --p-danger-soft: #fef2f2;
        --p-success: #10b981;
        --p-warning: #f59e0b;
        --p-warning-soft: #fffbeb;
        --p-border: #e5e7eb;
        --p-text: #1f2937;
        --p-muted: #6b7280;
        --p-bg: #f9fafb;
    }

    /* ================= رأس الصفحة ================= */
    .perm-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }
    .perm-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .perm-header-icon {
        width: 56px;
        height: 56px;
        border-radius: 14px;
        background: linear-gradient(135deg, #f59e0b, #f97316);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 8px 20px rgba(245, 158, 11, .3);
    }
    .perm-header h3 {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
        color: var(--p-text);
    }
    .perm-header p {
        margin: 3px 0 0;
        font-size: 14px;
        color: var(--p-muted);
    }

    .perm-btn-back {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 13px 22px;
        background: #fff;
        color: var(--p-text) !important;
        border: 1px solid var(--p-border);
        border-radius: 12px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
    }
    .perm-btn-back:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(0,0,0,.08);
        background: var(--p-bg);
        color: var(--p-text);
    }

    /* ================= البطاقة ================= */
    .perm-card {
        background: #fff;
        border: 1px solid var(--p-border);
        border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0,0,0,.05);
        overflow: hidden;
    }

    /* ================= رأس البطاقة ================= */
    .perm-card-head {
        padding: 20px 26px;
        border-bottom: 1px solid var(--p-border);
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
    }
    .perm-card-head-left {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .perm-card-head-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: var(--p-warning-soft);
        color: var(--p-warning);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        flex-shrink: 0;
    }
    .perm-card-head h4 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--p-text);
    }
    .perm-card-head p {
        margin: 2px 0 0;
        font-size: 13px;
        color: var(--p-muted);
    }

    .perm-id-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 13px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 700;
        background: var(--p-primary-soft);
        color: var(--p-primary);
        border: 1px solid #c7d2fe;
        font-family: 'SFMono-Regular', Consolas, monospace;
    }

    /* ================= جسم النموذج ================= */
    .perm-form-body {
        padding: 26px;
    }

    .perm-form-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }
    @media (max-width: 768px) {
        .perm-form-grid { grid-template-columns: 1fr; }
    }

    .perm-field {
        display: flex;
        flex-direction: column;
        gap: 8px;
    }
    .perm-field.full { grid-column: 1 / -1; }

    .perm-field label {
        font-size: 14px;
        font-weight: 600;
        color: var(--p-text);
        display: flex;
        align-items: center;
        gap: 4px;
    }
    .perm-field label .req {
        color: var(--p-danger);
        font-weight: 700;
    }
    .perm-field label .optional {
        color: var(--p-muted);
        font-size: 12px;
        font-weight: 500;
        margin-right: 4px;
    }

    .perm-field input,
    .perm-field select,
    .perm-field textarea {
        width: 100%;
        padding: 12px 14px;
        border: 1px solid var(--p-border);
        border-radius: 10px;
        font-size: 15px;
        color: var(--p-text);
        background: var(--p-bg);
        outline: none;
        transition: border-color .2s ease, box-shadow .2s ease, background .2s ease;
        font-family: inherit;
        text-align: right;
    }
    .perm-field input:focus,
    .perm-field select:focus,
    .perm-field textarea:focus {
        background: #fff;
        border-color: var(--p-primary);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, .12);
    }
    .perm-field input.is-invalid,
    .perm-field select.is-invalid {
        border-color: var(--p-danger);
        background: var(--p-danger-soft);
    }
    .perm-field input.is-invalid:focus,
    .perm-field select.is-invalid:focus {
        box-shadow: 0 0 0 4px rgba(239, 68, 68, .14);
    }

    /* حالة القراءة فقط / المعطّل */
    .perm-field input:disabled,
    .perm-field select:disabled {
        background: #f3f4f6;
        color: var(--p-muted);
        cursor: not-allowed;
        border-style: dashed;
        font-family: 'SFMono-Regular', Consolas, monospace;
        font-size: 13.5px;
    }

    .perm-field .hint {
        font-size: 12.5px;
        color: var(--p-muted);
        line-height: 1.5;
        display: flex;
        align-items: center;
        gap: 6px;
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .perm-field .hint i { font-size: 11px; }

    .perm-field .error-msg {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-size: 12.5px;
        color: var(--p-danger);
        font-weight: 600;
        background: var(--p-danger-soft);
        border: 1px solid #fecaca;
        border-radius: 8px;
        padding: 6px 10px;
        margin-top: 4px;
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .perm-field .error-msg i { font-size: 12px; }

    /* ================= الفوتر ================= */
    .perm-form-footer {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 10px;
        padding: 20px 26px;
        border-top: 1px solid var(--p-border);
        background: var(--p-bg);
        flex-wrap: wrap;
        flex-direction: row-reverse;
    }

    .perm-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        border: 1px solid transparent;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease, color .2s ease;
    }
    .perm-btn:hover { transform: translateY(-2px); }

    .perm-btn.cancel {
        background: #fff;
        color: var(--p-text);
        border-color: var(--p-border);
    }
    .perm-btn.cancel:hover {
        background: #fff;
        box-shadow: 0 6px 16px rgba(0,0,0,.08);
        color: var(--p-text);
    }

    .perm-btn.submit {
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff !important;
        box-shadow: 0 6px 16px rgba(99, 102, 241, .35);
    }
    .perm-btn.submit:hover {
        box-shadow: 0 10px 22px rgba(99, 102, 241, .45);
        color: #fff;
    }

    /* ================= التنبيهات ================= */
    .perm-toast-wrap {
        position: fixed;
        top: 24px;
        left: 24px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-width: 380px;
    }
    .perm-toast {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 15px 20px;
        background: #fff;
        border-radius: 12px;
        border-right: 4px solid var(--p-success);
        box-shadow: 0 12px 28px rgba(0,0,0,.12);
        min-width: 280px;
        font-size: 15px;
        color: var(--p-text);
        font-weight: 500;
        animation: permToastIn .35s ease both;
        flex-direction: row-reverse;
    }
    .perm-toast i { color: var(--p-success); font-size: 19px; }
    .perm-toast.error { border-right-color: var(--p-danger); }
    .perm-toast.error i { color: var(--p-danger); }
    @keyframes permToastIn {
        from { opacity: 0; transform: translateX(-40px); }
        to   { opacity: 1; transform: translateX(0); }
    }
    .perm-toast.hide {
        opacity: 0;
        transform: translateX(-40px);
        transition: opacity .3s ease, transform .3s ease;
    }

    /* ================= استجابة الجوال ================= */
    @media (max-width: 640px) {
        .perm-header h3 { font-size: 20px; }
        .perm-header-icon { width: 48px; height: 48px; font-size: 20px; }
        .perm-form-body { padding: 18px; }
        .perm-card-head { padding: 16px 18px; }
        .perm-form-footer { padding: 16px 18px; }
        .perm-btn { flex: 1; justify-content: center; }
        .perm-toast-wrap { top: 12px; left: 12px; right: 12px; }
        .perm-toast { min-width: auto; }
    }
</style>

<div class="main-content-inner perm-page" dir="rtl">
    <div class="main-content-wrap">

        {{-- الإشعارات --}}
        <div class="perm-toast-wrap" id="permToastWrap">
            @if(session('success'))
                <div class="perm-toast">
                    <i class="fa-solid fa-circle-check"></i>
                    <span>{{ session('success') }}</span>
                </div>
            @endif
            @if(session('error'))
                <div class="perm-toast error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>{{ session('error') }}</span>
                </div>
            @endif
            @if($errors->any())
                <div class="perm-toast error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>يوجد {{ $errors->count() }} خطأ في النموذج. يرجى المراجعة.</span>
                </div>
            @endif
        </div>

        {{-- رأس الصفحة --}}
        <div class="perm-header">
            <div class="perm-header-left">
                <div class="perm-header-icon">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>
                <div>
                    <h3>تعديل عقدة الشجرة</h3>
                    <p>تحديث بيانات العقدة الحالية في الشجرة الهرمية</p>
                </div>
            </div>
            <a class="perm-btn-back" href="{{ route('admin.tree-nodes.index') }}">
                <i class="fa-solid fa-arrow-right"></i>
                <span>العودة للقائمة</span>
            </a>
        </div>

        {{-- البطاقة --}}
        <div class="perm-card">

            {{-- رأس البطاقة --}}
            <div class="perm-card-head">
                <div class="perm-card-head-left">
                    <div class="perm-card-head-icon">
                        <i class="fa-solid fa-sitemap"></i>
                    </div>
                    <div>
                        <h4>تعديل بيانات العقدة</h4>
                        <p>الحقول المعلّمة بـ <span style="color:var(--p-danger);font-weight:700;">*</span> إلزامية</p>
                    </div>
                </div>
                <span class="perm-id-badge">
                    <i class="fa-solid fa-hashtag"></i>
                    القيمة: {{ $node->value }}
                </span>
            </div>

            {{-- النموذج --}}
            <form action="{{ route('admin.tree-nodes.update', ['tree_node' => $node->value]) }}" method="POST">
                @csrf
                @method('PUT')

                <div class="perm-form-body">
                    <div class="perm-form-grid">

                        {{-- قيمة العقدة (معطّلة) --}}
                        <div class="perm-field">
                            <label for="value">
                                قيمة العقدة <span class="optional">(للقراءة فقط)</span>
                            </label>
                            <input
                                type="text"
                                id="value"
                                value="{{ $node->value }}"
                                disabled
                            >
                            <span class="hint">
                                <i class="fa-solid fa-circle-info"></i>
                                هذه القيمة مُدارة بواسطة Oracle.
                            </span>
                        </div>

                        {{-- المستوى (معطّل) --}}
                        <div class="perm-field">
                            <label for="ilevel">
                                المستوى <span class="optional">(للقراءة فقط)</span>
                            </label>
                            <input
                                type="number"
                                id="ilevel"
                                value="{{ $node->ilevel }}"
                                disabled
                            >
                            <span class="hint">
                                <i class="fa-solid fa-circle-info"></i>
                                يتم حساب المستوى تلقائياً بناءً على العقدة الأب.
                            </span>
                        </div>

                        {{-- التسمية بالعربية --}}
                        <div class="perm-field">
                            <label for="label">
                                التسمية بالعربية <span class="req">*</span>
                            </label>
                            <input
                                type="text"
                                id="label"
                                name="label"
                                placeholder="أدخل التسمية بالعربية"
                                value="{{ old('label', $node->label) }}"
                                class="{{ $errors->has('label') ? 'is-invalid' : '' }}"
                                required
                            >
                            @error('label')
                                <span class="error-msg">
                                    <i class="fa-solid fa-circle-exclamation"></i>
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                        {{-- التسمية بالإنجليزية --}}
                        <div class="perm-field">
                            <label for="label_eng">
                                التسمية بالإنجليزية <span class="optional">(اختياري)</span>
                            </label>
                            <input
                                type="text"
                                id="label_eng"
                                name="label_eng"
                                placeholder="أدخل التسمية بالإنجليزية"
                                value="{{ old('label_eng', $node->label_eng) }}"
                                class="{{ $errors->has('label_eng') ? 'is-invalid' : '' }}"
                            >
                            @error('label_eng')
                                <span class="error-msg">
                                    <i class="fa-solid fa-circle-exclamation"></i>
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                        {{-- العقدة الأب --}}
                        <div class="perm-field full">
                            <label for="parent_value">
                                العقدة الأب <span class="req">*</span>
                            </label>
                            <select
                                id="parent_value"
                                name="parent_value"
                                class="{{ $errors->has('parent_value') ? 'is-invalid' : '' }}"
                                required
                            >
                                <option value="">— اختر العقدة الأب —</option>

                                @foreach ($parents as $parent)
                                    <option
                                        value="{{ $parent->value }}"
                                        {{ (string) old('parent_value', $node->parent_value) === (string) $parent->value ? 'selected' : '' }}
                                    >
                                        {{ $parent->label }} ({{ $parent->value }})
                                    </option>
                                @endforeach
                            </select>
                            <span class="hint">
                                <i class="fa-solid fa-circle-info"></i>
                                عند تغيير العقدة الأب، قد يتم إعادة حساب المستوى تلقائياً.
                            </span>
                            @error('parent_value')
                                <span class="error-msg">
                                    <i class="fa-solid fa-circle-exclamation"></i>
                                    {{ $message }}
                                </span>
                            @enderror
                        </div>

                    </div>
                </div>

                {{-- الفوتر --}}
                <div class="perm-form-footer">
                    <a href="{{ route('admin.tree-nodes.index') }}" class="perm-btn cancel">
                        <i class="fa-solid fa-xmark"></i>
                        <span>إلغاء</span>
                    </a>
                    <button type="submit" class="perm-btn submit">
                        <i class="fa-solid fa-check"></i>
                        <span>تحديث العقدة</span>
                    </button>
                </div>

            </form>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    /* إخفاء تلقائي للإشعارات */
    document.querySelectorAll('.perm-toast').forEach(function (toast) {
        setTimeout(function () {
            toast.classList.add('hide');
            setTimeout(function () { toast.remove(); }, 300);
        }, 4500);
    });

})();
</script>

@endsection