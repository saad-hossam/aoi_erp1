@extends('layouts.dashboard.app')
@section('content')

{{-- Font Awesome --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
    .perm-page {
        --p-primary: #6366f1;
        --p-primary-soft: #eef2ff;
        --p-danger: #ef4444;
        --p-danger-soft: #fef2f2;
        --p-success: #10b981;
        --p-warning: #f59e0b;
        --p-warning-soft: #fffbeb;
        --p-info: #0ea5e9;
        --p-info-soft: #e0f2fe;
        --p-border: #e5e7eb;
        --p-text: #1f2937;
        --p-muted: #6b7280;
        --p-bg: #f9fafb;
    }

    /* ================= رأس الصفحة ================= */
    .perm-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }
    .perm-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .perm-header-icon {
        width: 56px;
        height: 56px;
        border-radius: 14px;
        background: linear-gradient(135deg, #0ea5e9, #6366f1);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 8px 20px rgba(14, 165, 233, .3);
    }
    .perm-header h3 {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
        color: var(--p-text);
    }
    .perm-header p {
        margin: 3px 0 0;
        font-size: 14px;
        color: var(--p-muted);
    }

    .perm-header-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
    }

    .perm-btn-back {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 13px 22px;
        background: #fff;
        color: var(--p-text) !important;
        border: 1px solid var(--p-border);
        border-radius: 12px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
    }
    .perm-btn-back:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(0,0,0,.08);
        background: var(--p-bg);
        color: var(--p-text);
    }

    .perm-btn-edit {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 13px 22px;
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff !important;
        border: none;
        border-radius: 12px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        box-shadow: 0 6px 16px rgba(99, 102, 241, .35);
        transition: transform .2s ease, box-shadow .2s ease;
    }
    .perm-btn-edit:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 22px rgba(99, 102, 241, .45);
        color: #fff;
    }

    /* ================= البطاقة ================= */
    .perm-card {
        background: #fff;
        border: 1px solid var(--p-border);
        border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0,0,0,.05);
        overflow: hidden;
    }

    /* ================= رأس البطاقة ================= */
    .perm-card-head {
        padding: 20px 26px;
        border-bottom: 1px solid var(--p-border);
        background: #fff;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 12px;
        flex-wrap: wrap;
    }
    .perm-card-head-left {
        display: flex;
        align-items: center;
        gap: 12px;
    }
    .perm-card-head-icon {
        width: 40px;
        height: 40px;
        border-radius: 10px;
        background: var(--p-primary-soft);
        color: var(--p-primary);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 16px;
        flex-shrink: 0;
    }
    .perm-card-head h4 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--p-text);
    }
    .perm-card-head p {
        margin: 2px 0 0;
        font-size: 13px;
        color: var(--p-muted);
    }

    .perm-id-badge {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 13px;
        border-radius: 8px;
        font-size: 13px;
        font-weight: 700;
        background: var(--p-primary-soft);
        color: var(--p-primary);
        border: 1px solid #c7d2fe;
        font-family: 'SFMono-Regular', Consolas, monospace;
    }

    /* ================= جسم البطاقة ================= */
    .perm-detail-body {
        padding: 26px;
    }

    .perm-detail-grid {
        display: grid;
        grid-template-columns: repeat(2, 1fr);
        gap: 20px;
    }
    @media (max-width: 768px) {
        .perm-detail-grid { grid-template-columns: 1fr; }
    }

    .perm-detail-item {
        display: flex;
        flex-direction: column;
        gap: 6px;
    }
    .perm-detail-item.full { grid-column: 1 / -1; }

    .perm-detail-label {
        font-size: 12.5px;
        font-weight: 700;
        color: var(--p-muted);
        text-transform: uppercase;
        letter-spacing: .5px;
        display: flex;
        align-items: center;
        gap: 6px;
    }
    .perm-detail-label i {
        font-size: 12px;
        color: var(--p-primary);
    }

    .perm-detail-value {
        padding: 12px 14px;
        background: var(--p-bg);
        border: 1px solid var(--p-border);
        border-radius: 10px;
        font-size: 15px;
        color: var(--p-text);
        font-weight: 500;
        word-break: break-word;
        min-height: 46px;
        display: flex;
        align-items: center;
    }
    .perm-detail-value.mono {
        font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace;
        font-size: 13.5px;
        color: #4b5563;
        background: #f3f4f6;
    }
    .perm-detail-value.empty {
        color: var(--p-muted);
        font-style: italic;
        font-weight: 400;
    }

    /* ================= شارة ================= */
    .perm-badge {
        display: inline-flex;
        align-items: center;
        gap: 5px;
        padding: 5px 11px;
        border-radius: 8px;
        font-size: 12.5px;
        font-weight: 600;
        background: #ecfdf5;
        color: #059669;
        border: 1px solid #a7f3d0;
        margin: 2px;
    }
    .perm-badge.inactive {
        background: #f3f4f6;
        color: #6b7280;
        border-color: #e5e7eb;
    }
    .perm-badge.type {
        background: var(--p-info-soft);
        color: var(--p-info);
        border-color: #bae6fd;
    }
    .perm-badge.level {
        background: var(--p-warning-soft);
        color: var(--p-warning);
        border-color: #fde68a;
    }
    .perm-badge.value {
        background: #f3f4f6;
        color: #4b5563;
        border-color: #e5e7eb;
        font-family: 'SFMono-Regular', Consolas, monospace;
        font-size: 12px;
    }

    /* ================= الفوتر ================= */
    .perm-detail-footer {
        display: flex;
        align-items: center;
        justify-content: flex-start;
        gap: 10px;
        padding: 20px 26px;
        border-top: 1px solid var(--p-border);
        background: var(--p-bg);
        flex-wrap: wrap;
        flex-direction: row-reverse;
    }

    .perm-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 24px;
        border-radius: 10px;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        text-decoration: none;
        border: 1px solid transparent;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease, color .2s ease;
    }
    .perm-btn:hover { transform: translateY(-2px); }

    .perm-btn.cancel {
        background: #fff;
        color: var(--p-text);
        border-color: var(--p-border);
    }
    .perm-btn.cancel:hover {
        background: #fff;
        box-shadow: 0 6px 16px rgba(0,0,0,.08);
        color: var(--p-text);
    }

    .perm-btn.submit {
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff !important;
        box-shadow: 0 6px 16px rgba(99, 102, 241, .35);
    }
    .perm-btn.submit:hover {
        box-shadow: 0 10px 22px rgba(99, 102, 241, .45);
        color: #fff;
    }

    /* ================= التنبيهات ================= */
    .perm-toast-wrap {
        position: fixed;
        top: 24px;
        left: 24px;
        z-index: 9999;
        display: flex;
        flex-direction: column;
        gap: 10px;
        max-width: 380px;
    }
    .perm-toast {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 15px 20px;
        background: #fff;
        border-radius: 12px;
        border-right: 4px solid var(--p-success);
        box-shadow: 0 12px 28px rgba(0,0,0,.12);
        min-width: 280px;
        font-size: 15px;
        color: var(--p-text);
        font-weight: 500;
        animation: permToastIn .35s ease both;
        flex-direction: row-reverse;
    }
    .perm-toast i { color: var(--p-success); font-size: 19px; }
    .perm-toast.error { border-right-color: var(--p-danger); }
    .perm-toast.error i { color: var(--p-danger); }
    @keyframes permToastIn {
        from { opacity: 0; transform: translateX(-40px); }
        to   { opacity: 1; transform: translateX(0); }
    }
    .perm-toast.hide {
        opacity: 0;
        transform: translateX(-40px);
        transition: opacity .3s ease, transform .3s ease;
    }

    /* ================= استجابة الجوال ================= */
    @media (max-width: 640px) {
        .perm-header h3 { font-size: 20px; }
        .perm-header-icon { width: 48px; height: 48px; font-size: 20px; }
        .perm-detail-body { padding: 18px; }
        .perm-card-head { padding: 16px 18px; }
        .perm-detail-footer { padding: 16px 18px; }
        .perm-btn { flex: 1; justify-content: center; }
        .perm-header-actions { width: 100%; }
        .perm-header-actions .perm-btn-back,
        .perm-header-actions .perm-btn-edit { flex: 1; justify-content: center; }
        .perm-toast-wrap { top: 12px; left: 12px; right: 12px; }
        .perm-toast { min-width: auto; }
    }
</style>

<div class="main-content-inner perm-page" dir="rtl">
    <div class="main-content-wrap">

        {{-- الإشعارات --}}
        <div class="perm-toast-wrap" id="permToastWrap">
            @if(session('success'))
                <div class="perm-toast">
                    <i class="fa-solid fa-circle-check"></i>
                    <span>{{ session('success') }}</span>
                </div>
            @endif
            @if(session('status'))
                <div class="perm-toast">
                    <i class="fa-solid fa-circle-check"></i>
                    <span>{{ session('status') }}</span>
                </div>
            @endif
            @if(session('error'))
                <div class="perm-toast error">
                    <i class="fa-solid fa-circle-exclamation"></i>
                    <span>{{ session('error') }}</span>
                </div>
            @endif
        </div>

        {{-- رأس الصفحة --}}
        <div class="perm-header">
            <div class="perm-header-left">
                <div class="perm-header-icon">
                    <i class="fa-solid fa-diagram-project"></i>
                </div>
                <div>
                    <h3>تفاصيل عقدة الشجرة</h3>
                    <p>عرض كامل بيانات العقدة الحالية</p>
                </div>
            </div>
            <div class="perm-header-actions">
                <a class="perm-btn-back" href="{{ route('admin.tree-nodes.index') }}">
                    <i class="fa-solid fa-arrow-right"></i>
                    <span>رجوع</span>
                </a>
                <a class="perm-btn-edit" href="{{ route('admin.tree-nodes.edit', ['tree_node' => $node->value]) }}">
                    <i class="fa-solid fa-pen"></i>
                    <span>تعديل</span>
                </a>
            </div>
        </div>

        {{-- البطاقة --}}
        <div class="perm-card">

            {{-- رأس البطاقة --}}
            <div class="perm-card-head">
                <div class="perm-card-head-left">
                    <div class="perm-card-head-icon">
                        <i class="fa-solid fa-circle-info"></i>
                    </div>
                    <div>
                        <h4>بيانات العقدة</h4>
                        <p>جميع الحقول معروضة للقراءة فقط</p>
                    </div>
                </div>
                <span class="perm-id-badge">
                    <i class="fa-solid fa-hashtag"></i>
                    القيمة: {{ $node->value }}
                </span>
            </div>

            {{-- جسم البطاقة --}}
            <div class="perm-detail-body">
                <div class="perm-detail-grid">

                    {{-- الكود --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-hashtag"></i>
                            الكود
                        </div>
                        <div class="perm-detail-value">
                            <span class="perm-badge value">
                                <i class="fa-solid fa-key"></i>
                                {{ $node->value }}
                            </span>
                        </div>
                    </div>

                    {{-- المستوى --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-layer-group"></i>
                            المستوى
                        </div>
                        <div class="perm-detail-value">
                            <span class="perm-badge level">
                                <i class="fa-solid fa-layer-group"></i>
                                {{ $node->ilevel }}
                            </span>
                        </div>
                    </div>

                    {{-- الاسم بالعربي --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-font"></i>
                            الاسم بالعربي
                        </div>
                        <div class="perm-detail-value">{{ $node->label }}</div>
                    </div>

                    {{-- الاسم بالإنجليزي --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-language"></i>
                            الاسم بالإنجليزي
                        </div>
                        @if($node->label_eng)
                            <div class="perm-detail-value">{{ $node->label_eng }}</div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                    {{-- الأب --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-arrow-up"></i>
                            الأب
                        </div>
                        @if($node->parent_value)
                            <div class="perm-detail-value">
                                <span class="perm-badge value">
                                    <i class="fa-solid fa-sitemap"></i>
                                    {{ $node->parent_value }}
                                </span>
                            </div>
                        @else
                            <div class="perm-detail-value empty">— جذر —</div>
                        @endif
                    </div>

                    {{-- نوع العنصر --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-tag"></i>
                            نوع العنصر
                        </div>
                        @if($node->node_type)
                            <div class="perm-detail-value">
                                <span class="perm-badge type">
                                    <i class="fa-solid fa-cube"></i>
                                    {{ $node->node_type }}
                                </span>
                            </div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                    {{-- حالة العنصر --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-circle-dot"></i>
                            حالة العنصر
                        </div>
                        @if($node->istate)
                            <div class="perm-detail-value">
                                <span class="perm-badge">
                                    <i class="fa-solid fa-circle-check"></i>
                                    {{ $node->istate }}
                                </span>
                            </div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                    {{-- كود الفورم --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-file-code"></i>
                            كود الفورم
                        </div>
                        @if($node->form_code)
                            <div class="perm-detail-value mono">{{ $node->form_code }}</div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                    {{-- اسم الـ Object --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-microchip"></i>
                            اسم الـ Object
                        </div>
                        @if($node->obj_name)
                            <div class="perm-detail-value mono">{{ $node->obj_name }}</div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                    {{-- نوع النظام --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-server"></i>
                            نوع النظام
                        </div>
                        @if($node->sys_type)
                            <div class="perm-detail-value">
                                <span class="perm-badge type">
                                    <i class="fa-solid fa-network-wired"></i>
                                    {{ $node->sys_type }}
                                </span>
                            </div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                    {{-- كود الفرع --}}
                    <div class="perm-detail-item">
                        <div class="perm-detail-label">
                            <i class="fa-solid fa-building"></i>
                            كود الفرع
                        </div>
                        @if($node->branch_code)
                            <div class="perm-detail-value mono">{{ $node->branch_code }}</div>
                        @else
                            <div class="perm-detail-value empty">—</div>
                        @endif
                    </div>

                </div>
            </div>

            {{-- الفوتر --}}
            <div class="perm-detail-footer">
                <a href="{{ route('admin.tree-nodes.index') }}" class="perm-btn cancel">
                    <i class="fa-solid fa-arrow-right"></i>
                    <span>رجوع</span>
                </a>
                <a href="{{ route('admin.tree-nodes.edit', ['tree_node' => $node->value]) }}" class="perm-btn submit">
                    <i class="fa-solid fa-pen"></i>
                    <span>تعديل العقدة</span>
                </a>
            </div>
        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    /* إخفاء تلقائي للإشعارات */
    document.querySelectorAll('.perm-toast').forEach(function (toast) {
        setTimeout(function () {
            toast.classList.add('hide');
            setTimeout(function () { toast.remove(); }, 300);
        }, 4500);
    });

})();
</script>

@endsection