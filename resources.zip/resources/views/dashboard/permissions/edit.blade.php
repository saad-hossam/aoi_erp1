@extends('layouts.dashboard.app')
@section('content')

{{-- Font Awesome --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
    .perm-edit {
        --pe-primary: #6366f1;
        --pe-primary-dark: #4f46e5;
        --pe-primary-soft: #eef2ff;
        --pe-warning: #f59e0b;
        --pe-warning-soft: #fef3c7;
        --pe-danger: #ef4444;
        --pe-danger-soft: #fef2f2;
        --pe-success: #10b981;
        --pe-border: #e5e7eb;
        --pe-text: #1f2937;
        --pe-muted: #6b7280;
        --pe-bg: #f9fafb;
    }

    /* رأس الصفحة */
    .pe-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }
    .pe-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .pe-header-icon {
        width: 56px;
        height: 56px;
        border-radius: 14px;
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 8px 20px rgba(99, 102, 241, .3);
    }
    .pe-header h3 {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
        color: var(--pe-text);
    }
    .pe-header p {
        margin: 3px 0 0;
        font-size: 14px;
        color: var(--pe-muted);
    }

    /* زر الرجوع */
    .pe-btn-back {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 11px 18px;
        background: #fff;
        color: var(--pe-text) !important;
        border: 1px solid var(--pe-border);
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: all .2s ease;
    }
    .pe-btn-back:hover {
        background: var(--pe-bg);
        transform: translateY(-2px);
        box-shadow: 0 6px 14px rgba(0,0,0,.06);
    }

    /* البطاقة */
    .pe-card {
        background: #fff;
        border: 1px solid var(--pe-border);
        border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0,0,0,.05);
        overflow: hidden;
        /* max-width: 640px; */
    }

    /* رأس البطاقة */
    .pe-card-head {
        padding: 20px 28px;
        border-bottom: 1px solid var(--pe-border);
        background: linear-gradient(180deg, #fff, #fafbff);
    }
    .pe-card-head h4 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--pe-text);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .pe-card-head h4 i {
        color: var(--pe-primary);
    }
    .pe-card-head p {
        margin: 4px 0 0;
        font-size: 13.5px;
        color: var(--pe-muted);
    }

    /* شريط التعديل */
    .pe-editing {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 14px 18px;
        margin-bottom: 22px;
        background: var(--pe-primary-soft);
        border-right: 4px solid var(--pe-primary);
        border-radius: 11px;
        font-size: 14px;
        color: var(--pe-text);
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .pe-editing i {
        color: var(--pe-primary);
        font-size: 16px;
        flex-shrink: 0;
    }
    .pe-editing strong {
        color: var(--pe-primary-dark);
        font-weight: 700;
    }
    .pe-editing code {
        background: rgba(99, 102, 241, .12);
        color: var(--pe-primary-dark);
        padding: 2px 7px;
        border-radius: 5px;
        font-size: 13px;
        font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
    }

    /* النموذج */
    .pe-form {
        padding: 28px;
    }

    /* الحقل */
    .pe-field {
        margin-bottom: 22px;
    }
    .pe-label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        color: var(--pe-text);
        margin-bottom: 8px;
    }
    .pe-label .pe-required {
        color: var(--pe-danger);
        margin-right: 2px;
    }

    .pe-input-wrap {
        position: relative;
    }
    .pe-input-wrap i {
        position: absolute;
        right: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--pe-muted);
        font-size: 15px;
        pointer-events: none;
        transition: color .2s ease;
    }

    .pe-input {
        width: 100%;
        padding: 13px 42px 13px 16px;
        border: 1px solid var(--pe-border);
        border-radius: 11px;
        font-size: 15px;
        color: var(--pe-text);
        background: var(--pe-bg);
        outline: none;
        transition: border-color .2s ease, box-shadow .2s ease, background .2s ease;
        text-align: right;
    }
    .pe-input::placeholder {
        color: #9ca3af;
    }
    .pe-input:focus {
        background: #fff;
        border-color: var(--pe-primary);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, .12);
    }
    .pe-input-wrap:focus-within i {
        color: var(--pe-primary);
    }

    /* حالة الخطأ */
    .pe-input.is-error {
        border-color: var(--pe-danger);
        background: #fff;
    }
    .pe-input.is-error:focus {
        box-shadow: 0 0 0 4px rgba(239, 68, 68, .12);
    }
    .pe-error {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        padding: 8px 12px;
        font-size: 13.5px;
        font-weight: 500;
        color: #991b1b;
        background: var(--pe-danger-soft);
        border-radius: 8px;
        border-right: 3px solid var(--pe-danger);
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .pe-error i {
        font-size: 13px;
    }

    /* تلميح */
    .pe-hint {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        font-size: 13px;
        color: var(--pe-muted);
    }
    .pe-hint i {
        font-size: 12px;
        color: #9ca3af;
    }

    /* معلومات إضافية */
    .pe-meta {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
        gap: 12px;
        padding: 16px 18px;
        background: var(--pe-bg);
        border: 1px dashed var(--pe-border);
        border-radius: 11px;
        margin-bottom: 22px;
    }
    .pe-meta-item {
        display: flex;
        flex-direction: column;
        gap: 3px;
    }
    .pe-meta-label {
        font-size: 11px;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: .5px;
        color: var(--pe-muted);
    }
    .pe-meta-value {
        font-size: 14px;
        font-weight: 600;
        color: var(--pe-text);
        display: flex;
        align-items: center;
        gap: 6px;
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .pe-meta-value i {
        color: var(--pe-primary);
        font-size: 12px;
    }

    /* الإجراءات */
    .pe-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        padding-top: 22px;
        border-top: 1px solid var(--pe-border);
        flex-direction: row-reverse;
        justify-content: flex-end;
    }

    .pe-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 22px;
        border-radius: 11px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
    }
    .pe-btn.primary {
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff;
        box-shadow: 0 6px 16px rgba(99, 102, 241, .35);
    }
    .pe-btn.primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 22px rgba(99, 102, 241, .45);
    }
    .pe-btn.primary:active {
        transform: translateY(0);
    }
    .pe-btn.ghost {
        background: #fff;
        color: var(--pe-text);
        border: 1px solid var(--pe-border);
    }
    .pe-btn.ghost:hover {
        background: var(--pe-bg);
        transform: translateY(-2px);
        box-shadow: 0 6px 14px rgba(0,0,0,.06);
    }
    .pe-btn.danger {
        background: var(--pe-danger);
        color: #fff;
        margin-left: auto;
    }
    .pe-btn.danger:hover {
        background: #dc2626;
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(239, 68, 68, .35);
    }

    /* التجاوب */
    @media (max-width: 640px) {
        .pe-header h3 { font-size: 20px; }
        .pe-header-icon { width: 48px; height: 48px; font-size: 20px; }
        .pe-form { padding: 20px; }
        .pe-card-head { padding: 16px 20px; }
        .pe-btn { flex: 1; justify-content: center; }
        .pe-btn.danger { margin-left: 0; }
    }
</style>

<div class="main-content-inner perm-edit" dir="rtl">
    <div class="main-content-wrap">

        {{-- رأس الصفحة --}}
        <div class="pe-header">
            <div class="pe-header-left">
                <div class="pe-header-icon">
                    <i class="fa-solid fa-pen-to-square"></i>
                </div>
                <div>
                    <h3>تعديل الصلاحية</h3>
                    <p>تحديث تفاصيل هذه الصلاحية</p>
                </div>
            </div>
            <a href="{{ route('permissions.index') }}" class="pe-btn-back">
                <i class="fa-solid fa-arrow-right"></i>
                <span>العودة للقائمة</span>
            </a>
        </div>

        {{-- البطاقة --}}
        <div class="pe-card">

            <div class="pe-card-head">
                <h4><i class="fa-solid fa-pen"></i> تفاصيل الصلاحية</h4>
            </div>

            <form action="{{ route('permissions.update', $permission->id) }}"
                  method="POST"
                  class="pe-form"
                  novalidate>
                @csrf
                @method('PUT')

                {{-- شريط التعديل --}}
                {{-- <div class="pe-editing">
                    <i class="fa-solid fa-circle-info"></i>
                    <div>
                        أنت تقوم بتعديل <strong>الصلاحية #{{ $permission->id }}</strong> —
                        <code>{{ $permission->name }}</code>
                    </div>
                </div> --}}

                {{-- حقل الاسم --}}
                <div class="pe-field">
                    <label class="pe-label" for="permName">
                        اسم الصلاحية <span class="pe-required">*</span>
                    </label>
                    <div class="pe-input-wrap">
                        <input
                            type="text"
                            id="permName"
                            name="name"
                            value="{{ old('name', $permission->name) }}"
                            placeholder="مثال: users.create"
                            class="pe-input @error('name') is-error @enderror"
                            autocomplete="off"
                        >
                        <i class="fa-solid fa-key"></i>
                    </div>

                    @error('name')
                        <div class="pe-error">
                            <i class="fa-solid fa-circle-exclamation"></i>
                            <span>{{ $message }}</span>
                        </div>
                    @else
                        <div class="pe-hint">
                            <i class="fa-solid fa-circle-info"></i>
                        </div>
                    @enderror
                </div>

                {{-- معلومات إضافية --}}
                <div class="pe-meta">
                    <div class="pe-meta-item">
                        <span class="pe-meta-label">المعرف</span>
                        <span class="pe-meta-value">
                            <i class="fa-solid fa-hashtag"></i>
                            {{ $permission->id }}
                        </span>
                    </div>
                    <div class="pe-meta-item">
                        <span class="pe-meta-label">الاسم الحالي</span>
                        <span class="pe-meta-value">
                            <i class="fa-solid fa-key"></i>
                            {{ $permission->name }}
                        </span>
                    </div>
                    @if($permission->created_at)
                    <div class="pe-meta-item">
                        <span class="pe-meta-label">تاريخ الإنشاء</span>
                        <span class="pe-meta-value">
                            <i class="fa-solid fa-calendar"></i>
                            {{ $permission->created_at->format('M d, Y') }}
                        </span>
                    </div>
                    @endif
                    @if($permission->updated_at)
                    <div class="pe-meta-item">
                        <span class="pe-meta-label">آخر تحديث</span>
                        <span class="pe-meta-value">
                            <i class="fa-solid fa-clock"></i>
                            {{ $permission->updated_at->diffForHumans() }}
                        </span>
                    </div>
                    @endif
                </div>

                {{-- الإجراءات --}}
                <div class="pe-actions">
                    <button type="submit" class="pe-btn primary">
                        <i class="fa-solid fa-check"></i>
                        <span>تحديث الصلاحية</span>
                    </button>
                    <a href="{{ route('permissions.index') }}" class="pe-btn ghost">
                        <i class="fa-solid fa-xmark"></i>
                        <span>إلغاء</span>
                    </a>
                </div>

            </form>

        </div>
    </div>
</div>

@endsection