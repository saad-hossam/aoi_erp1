@extends('layouts.dashboard.app')
@section('content')

{{-- Font Awesome --}}
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">

<style>
    .perm-create {
        --pc-primary: #6366f1;
        --pc-primary-dark: #4f46e5;
        --pc-primary-soft: #eef2ff;
        --pc-danger: #ef4444;
        --pc-danger-soft: #fef2f2;
        --pc-success: #10b981;
        --pc-border: #e5e7eb;
        --pc-text: #1f2937;
        --pc-muted: #6b7280;
        --pc-bg: #f9fafb;
    }

    /* رأس الصفحة */
    .pc-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 16px;
        flex-wrap: wrap;
        margin-bottom: 24px;
    }
    .pc-header-left {
        display: flex;
        align-items: center;
        gap: 14px;
    }
    .pc-header-icon {
        width: 56px;
        height: 56px;
        border-radius: 14px;
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 8px 20px rgba(99, 102, 241, .3);
    }
    .pc-header h3 {
        margin: 0;
        font-size: 24px;
        font-weight: 700;
        color: var(--pc-text);
    }
    .pc-header p {
        margin: 3px 0 0;
        font-size: 14px;
        color: var(--pc-muted);
    }

    /* زر الرجوع */
    .pc-btn-back {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 11px 18px;
        background: #fff;
        color: var(--pc-text) !important;
        border: 1px solid var(--pc-border);
        border-radius: 12px;
        font-size: 14px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        transition: all .2s ease;
    }
    .pc-btn-back:hover {
        background: var(--pc-bg);
        transform: translateY(-2px);
        box-shadow: 0 6px 14px rgba(0,0,0,.06);
    }

    /* البطاقة */
    .pc-card {
        background: #fff;
        border: 1px solid var(--pc-border);
        border-radius: 16px;
        box-shadow: 0 4px 20px rgba(0,0,0,.05);
        overflow: hidden;
        /* max-width: 640px; */
    }

    /* شريط رأس البطاقة */
    .pc-card-head {
        padding: 20px 28px;
        border-bottom: 1px solid var(--pc-border);
        background: linear-gradient(180deg, #fff, #fafbff);
    }
    .pc-card-head h4 {
        margin: 0;
        font-size: 17px;
        font-weight: 700;
        color: var(--pc-text);
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .pc-card-head h4 i {
        color: var(--pc-primary);
    }
    .pc-card-head p {
        margin: 4px 0 0;
        font-size: 13.5px;
        color: var(--pc-muted);
    }

    /* النموذج */
    .pc-form {
        padding: 28px;
    }

    /* الحقل */
    .pc-field {
        margin-bottom: 22px;
    }
    .pc-label {
        display: block;
        font-size: 14px;
        font-weight: 600;
        color: var(--pc-text);
        margin-bottom: 8px;
    }
    .pc-label .pc-required {
        color: var(--pc-danger);
        margin-right: 2px;
    }

    .pc-input-wrap {
        position: relative;
    }
    .pc-input-wrap i {
        position: absolute;
        right: 14px;
        top: 50%;
        transform: translateY(-50%);
        color: var(--pc-muted);
        font-size: 15px;
        pointer-events: none;
        transition: color .2s ease;
    }

    .pc-input {
        width: 100%;
        padding: 13px 42px 13px 16px;
        border: 1px solid var(--pc-border);
        border-radius: 11px;
        font-size: 15px;
        color: var(--pc-text);
        background: var(--pc-bg);
        outline: none;
        transition: border-color .2s ease, box-shadow .2s ease, background .2s ease;
        text-align: right;
    }
    .pc-input::placeholder {
        color: #9ca3af;
    }
    .pc-input:focus {
        background: #fff;
        border-color: var(--pc-primary);
        box-shadow: 0 0 0 4px rgba(99, 102, 241, .12);
    }
    .pc-input:focus + i,
    .pc-input-wrap:focus-within i {
        color: var(--pc-primary);
    }

    /* حالة الخطأ */
    .pc-input.is-error {
        border-color: var(--pc-danger);
        background: #fff;
    }
    .pc-input.is-error:focus {
        box-shadow: 0 0 0 4px rgba(239, 68, 68, .12);
    }
    .pc-error {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        padding: 8px 12px;
        font-size: 13.5px;
        font-weight: 500;
        color: #991b1b;
        background: var(--pc-danger-soft);
        border-radius: 8px;
        border-right: 3px solid var(--pc-danger);
        flex-direction: row-reverse;
        justify-content: flex-end;
    }
    .pc-error i {
        font-size: 13px;
    }

    /* تلميح */
    .pc-hint {
        display: flex;
        align-items: center;
        gap: 6px;
        margin-top: 8px;
        font-size: 13px;
        color: var(--pc-muted);
    }
    .pc-hint i {
        font-size: 12px;
        color: #9ca3af;
    }

    /* الإجراءات */
    .pc-actions {
        display: flex;
        align-items: center;
        gap: 10px;
        flex-wrap: wrap;
        padding-top: 6px;
        border-top: 1px solid var(--pc-border);
        margin-top: 4px;
        padding-top: 22px;
        flex-direction: row-reverse;
        justify-content: flex-end;
    }

    .pc-btn {
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 12px 22px;
        border-radius: 11px;
        font-size: 15px;
        font-weight: 600;
        text-decoration: none;
        cursor: pointer;
        border: none;
        transition: transform .2s ease, box-shadow .2s ease, background .2s ease;
    }
    .pc-btn.primary {
        background: linear-gradient(135deg, #6366f1, #8b5cf6);
        color: #fff;
        box-shadow: 0 6px 16px rgba(99, 102, 241, .35);
    }
    .pc-btn.primary:hover {
        transform: translateY(-2px);
        box-shadow: 0 10px 22px rgba(99, 102, 241, .45);
    }
    .pc-btn.primary:active {
        transform: translateY(0);
    }
    .pc-btn.ghost {
        background: #fff;
        color: var(--pc-text);
        border: 1px solid var(--pc-border);
    }
    .pc-btn.ghost:hover {
        background: var(--pc-bg);
        transform: translateY(-2px);
        box-shadow: 0 6px 14px rgba(0,0,0,.06);
    }

    /* التجاوب */
    @media (max-width: 640px) {
        .pc-header h3 { font-size: 20px; }
        .pc-header-icon { width: 48px; height: 48px; font-size: 20px; }
        .pc-form { padding: 20px; }
        .pc-card-head { padding: 16px 20px; }
        .pc-btn { flex: 1; justify-content: center; }
    }
</style>

<div class="main-content-inner perm-create" dir="rtl">
    <div class="main-content-wrap">

        {{-- رأس الصفحة --}}
        <div class="pc-header">
            <div class="pc-header-left">
                <div class="pc-header-icon">
                    <i class="fa-solid fa-shield-halved"></i>
                </div>
                <div>
                    <h3>إنشاء صلاحية</h3>
                    <p>إضافة صلاحية جديدة إلى النظام</p>
                </div>
            </div>
            <a href="{{ route('permissions.index') }}" class="pc-btn-back">
                <i class="fa-solid fa-arrow-right"></i>
                <span>العودة للقائمة</span>
            </a>
        </div>

        {{-- البطاقة --}}
        <div class="pc-card">

            <div class="pc-card-head">
                <h4><i class="fa-solid fa-plus-circle"></i> تفاصيل الصلاحية الجديدة</h4>
            </div>

            <form action="{{ route('permissions.store') }}" method="POST" class="pc-form" novalidate>
                @csrf

                <div class="pc-field">
                    <label class="pc-label" for="permName">
                        اسم الصلاحية <span class="pc-required">*</span>
                    </label>
                    <div class="pc-input-wrap">
                        <input
                            type="text"
                            id="permName"
                            name="name"
                            value="{{ old('name') }}"
                            placeholder="مثال: users.create"
                            class="pc-input @error('name') is-error @enderror"
                            autocomplete="off"
                            autofocus
                        >
                        <i class="fa-solid fa-key"></i>
                    </div>

                    @error('name')
                        <div class="pc-error">
                            <i class="fa-solid fa-circle-exclamation"></i>
                            <span>{{ $message }}</span>
                        </div>
                    @else
                        <div class="pc-hint">
                            <i class="fa-solid fa-circle-info"></i>
                        </div>
                    @enderror
                </div>

                <div class="pc-actions">
                    <button type="submit" class="pc-btn primary">
                        <i class="fa-solid fa-check"></i>
                        <span>إنشاء الصلاحية</span>
                    </button>
                    <a href="{{ route('permissions.index') }}" class="pc-btn ghost">
                        <i class="fa-solid fa-xmark"></i>
                        <span>إلغاء</span>
                    </a>
                </div>
            </form>

        </div>
    </div>
</div>

@endsection